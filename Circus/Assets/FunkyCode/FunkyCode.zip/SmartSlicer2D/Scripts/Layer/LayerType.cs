﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Slicer2D {
	
	public enum LayerType {
		All, 
		Selected
	}

}
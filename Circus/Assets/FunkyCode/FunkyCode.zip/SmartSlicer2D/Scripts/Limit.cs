﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Slicer2D {
	
	public class Limit {
		public bool enabled = false;
		public int counter = 0;
		public int maxSlices = 10;
	}

}
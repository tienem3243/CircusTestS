﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utilities2D;

namespace Slicer2D.Trail {

	public class Object {
		public Vector2D lastPosition;
		public List<Point> pointsList = new List<Point>();
	}

}